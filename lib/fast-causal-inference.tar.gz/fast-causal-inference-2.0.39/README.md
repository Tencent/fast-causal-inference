causal inference package.
contain ols, ttest, delta-method etc...

install:
yum install -y libjpeg-devel
yum install python3-devel -y
yum install python-devel -y
yum install postgresql-devel* -y
yum install gcc-c++ -y

pip3.6 install requests
