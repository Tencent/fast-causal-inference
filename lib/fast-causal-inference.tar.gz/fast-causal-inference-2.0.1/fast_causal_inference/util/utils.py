import os
import pandas


def get_user():
    if str(os.environ.get("JUPYTERHUB_USER")) != "None":
        return str(os.environ.get("JUPYTERHUB_USER"))
    elif str(os.environ.get("USER")) != "None":
        return str(os.environ.get("USER"))
    elif str(os.environ.get("CURRENT_USER")) != "None":
        return str(os.environ.get("CURRENT_USER"))
    else:
        return str('default')


def output_auto_boxing(res):
    lines = res.split('\n')
    results = []
    for i in range(len(lines)):
        if len(lines[i]) != 0:
            columns = lines[i].split('\t')
            result_line = []
            for j in range(len(columns)):
                if columns[j].isdigit():
                    columns[j] = int(columns[j])
                else:
                    try:
                        columns[j] = float(columns[j])
                    except Exception:
                        pass
                result_line.append(columns[j])
            results.append(result_line)
    return results


def output_dataframe(res):
    return pandas.DataFrame(list(eval(res)))

def to_pandas(res):
    data = list()
    columns = None
    for line in res:
        i = 1
        for inner_line in line.splitlines():
            if not columns:
                columns = list(filter(lambda x: x != '', inner_line.split(' ')))
            if i == 2:
                data.append(list(filter(lambda x: x != '', inner_line.split(' '))))
            i += 1
    return pandas.DataFrame(data, columns=columns)
